function s=get_name(a)

s=[get_name(a.algorithm)];
eval_name
